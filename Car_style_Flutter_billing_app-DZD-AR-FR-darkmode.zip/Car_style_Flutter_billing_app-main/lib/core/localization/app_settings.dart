
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

class AppSettings {
  static const _boxName = 'app_settings';
  static late Box _box;
  static final ValueNotifier<Locale> locale = ValueNotifier(const Locale('en'));
  static final ValueNotifier<ThemeMode> themeMode = ValueNotifier(ThemeMode.light);

  static Future<void> init() async {
    _box = await Hive.openBox(_boxName);
    final language = (_box.get('language', defaultValue: 'en') as String);
    final theme = (_box.get('theme', defaultValue: 'light') as String);
    locale.value = Locale(language);
    themeMode.value = _themeFromString(theme);
  }

  static Future<void> setLanguage(String language) async {
    await _box.put('language', language);
    locale.value = Locale(language);
  }

  static Future<void> setThemeMode(ThemeMode mode) async {
    await _box.put('theme', _themeToString(mode));
    themeMode.value = mode;
  }

  static ThemeMode _themeFromString(String value) {
    switch (value) {
      case 'dark': return ThemeMode.dark;
      case 'system': return ThemeMode.system;
      default: return ThemeMode.light;
    }
  }

  static String _themeToString(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.dark: return 'dark';
      case ThemeMode.system: return 'system';
      case ThemeMode.light: return 'light';
    }
  }
}
