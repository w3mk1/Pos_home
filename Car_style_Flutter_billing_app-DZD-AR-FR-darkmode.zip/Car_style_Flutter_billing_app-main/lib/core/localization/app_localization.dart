
import 'package:flutter/material.dart';

class AppLocalization {
  final Locale locale;
  AppLocalization(this.locale);

  static const supportedLocales = [
    Locale('en'),
    Locale('fr'),
    Locale('ar'),
  ];

  static const Map<String, Map<String, String>> _values = {
    'en': {
      'settings':'Settings','language':'Language','english':'English','french':'French','arabic':'Arabic',
      'appearance':'Appearance','darkMode':'Dark mode','lightMode':'Light mode','systemMode':'System',
      'management':'Management','products':'Products','manageProducts':'Manage stock and barcodes',
      'shopDetails':'Shop Details','editBusiness':'Edit business info & address','hardware':'Hardware',
      'printDevice':'Print Device','printerConnected':'Printer connected','noPrinter':'No printer connected',
      'connected':'CONNECTED','connectedToPrinter':'Connected to printer','barcode':'Barcode',
      'scanEnterBarcode':'Scan or enter barcode','enterBarcode':'Please enter a barcode',
      'tapScanner':'Tap the icon to open camera scanner','productName':'Product Name',
      'enterName':'Please enter a name','price':'Price','addProduct':'Add Product','editProduct':'Edit Product',
      'saveChanges':'Save Changes','saveDetails':'Save Details','cancel':'Cancel','delete':'Delete',
      'deleteProduct':'Delete Product','checkout':'Checkout','printedSuccessfully':'Printed successfully',
      'shop':'Shop','total':'Total','scanToPay':'Scan to Pay','grandTotal':'GRAND TOTAL','printReceipt':'Print Receipt',
      'reviewOrder':'Review Order','cameraOff':'Camera is turned off','turnCamera':'Turn on your camera to start scanning barcodes and items automatically.',
      'turnOnCamera':'Turn on Camera','scannedItems':'Scanned Items','itemsTotal':'{count} items total',
      'listEmpty':'List is empty','scanItemsHint':'Scanned items will appear here as you scan them with the camera above.',
      'scanBarcode':'Scan Barcode','alignBarcode':'Align barcode within frame','productManagement':'Product Management',
      'noProducts':'No products found. Add some!','noMatches':'No products match your search.',
      'confirmDelete':'Are you sure you want to delete {name}?','shopSaved':'Shop details saved!',
      'generalInfo':'General Information','receiptInfo':'These details will appear on your digital and printed receipts.',
      'shopName':'Shop Name','address1':'Address Line 1','address2':'Address Line 2 (Optional)','phone':'Phone Number',
      'upi':'UPI ID','footer':'Receipt Footer Text','maxChars':'Max 150 chars',
      'save':'Save','currency':'Currency','dzd':'Algerian Dinar (DZD)',
      'connectHelp':"To connect a new device, tap on the Settings gear to pair in phone's Bluetooth settings, then return and hit Refresh.",
      'refresh':'Refresh','error':'Error','required':'Required','cameraScanner':'Camera scanner',
    },
    'fr': {
      'settings':'Paramètres','language':'Langue','english':'Anglais','french':'Français','arabic':'Arabe',
      'appearance':'Apparence','darkMode':'Mode sombre','lightMode':'Mode clair','systemMode':'Système',
      'management':'Gestion','products':'Produits','manageProducts':'Gérer le stock et les codes-barres',
      'shopDetails':'Détails du magasin','editBusiness':'Modifier les informations et l’adresse','hardware':'Matériel',
      'printDevice':'Imprimante','printerConnected':'Imprimante connectée','noPrinter':'Aucune imprimante connectée',
      'connected':'CONNECTÉ','connectedToPrinter':'Imprimante connectée','barcode':'Code-barres',
      'scanEnterBarcode':'Scannez ou saisissez le code-barres','enterBarcode':'Veuillez saisir un code-barres',
      'tapScanner':'Appuyez sur l’icône pour ouvrir le scanner','productName':'Nom du produit',
      'enterName':'Veuillez saisir un nom','price':'Prix','addProduct':'Ajouter un produit','editProduct':'Modifier le produit',
      'saveChanges':'Enregistrer les modifications','saveDetails':'Enregistrer','cancel':'Annuler','delete':'Supprimer',
      'deleteProduct':'Supprimer le produit','checkout':'Paiement','printedSuccessfully':'Impression réussie',
      'shop':'Magasin','total':'Total','scanToPay':'Scanner pour payer','grandTotal':'TOTAL GÉNÉRAL','printReceipt':'Imprimer le reçu',
      'reviewOrder':'Récapitulatif','cameraOff':'Caméra désactivée','turnCamera':'Activez la caméra pour scanner automatiquement les codes-barres et les articles.',
      'turnOnCamera':'Activer la caméra','scannedItems':'Articles scannés','itemsTotal':'{count} articles au total',
      'listEmpty':'La liste est vide','scanItemsHint':'Les articles scannés apparaîtront ici.',
      'scanBarcode':'Scanner le code-barres','alignBarcode':'Alignez le code-barres dans le cadre','productManagement':'Gestion des produits',
      'noProducts':'Aucun produit trouvé. Ajoutez-en !','noMatches':'Aucun produit ne correspond à votre recherche.',
      'confirmDelete':'Voulez-vous vraiment supprimer {name} ?','shopSaved':'Détails du magasin enregistrés !',
      'generalInfo':'Informations générales','receiptInfo':'Ces informations apparaîtront sur vos reçus numériques et imprimés.',
      'shopName':'Nom du magasin','address1':'Adresse ligne 1','address2':'Adresse ligne 2 (facultatif)','phone':'Numéro de téléphone',
      'upi':'ID UPI','footer':'Texte de pied de reçu','maxChars':'150 caractères max.',
      'save':'Enregistrer','currency':'Devise','dzd':'Dinar algérien (DZD)',
      'connectHelp':"Pour connecter un nouvel appareil, ouvrez les réglages Bluetooth avec l’icône Paramètres, associez-le, puis revenez et appuyez sur Actualiser.",
      'refresh':'Actualiser','error':'Erreur','required':'Obligatoire','cameraScanner':'Scanner caméra',
    },
    'ar': {
      'settings':'الإعدادات','language':'اللغة','english':'الإنجليزية','french':'الفرنسية','arabic':'العربية',
      'appearance':'المظهر','darkMode':'الوضع الداكن','lightMode':'الوضع الفاتح','systemMode':'النظام',
      'management':'الإدارة','products':'المنتجات','manageProducts':'إدارة المخزون والباركود',
      'shopDetails':'تفاصيل المتجر','editBusiness':'تعديل معلومات النشاط والعنوان','hardware':'الأجهزة',
      'printDevice':'جهاز الطباعة','printerConnected':'الطابعة متصلة','noPrinter':'لا توجد طابعة متصلة',
      'connected':'متصل','connectedToPrinter':'تم الاتصال بالطابعة','barcode':'الباركود',
      'scanEnterBarcode':'امسح الباركود أو أدخله','enterBarcode':'يرجى إدخال الباركود',
      'tapScanner':'اضغط على الأيقونة لفتح ماسح الكاميرا','productName':'اسم المنتج',
      'enterName':'يرجى إدخال الاسم','price':'السعر','addProduct':'إضافة منتج','editProduct':'تعديل المنتج',
      'saveChanges':'حفظ التغييرات','saveDetails':'حفظ التفاصيل','cancel':'إلغاء','delete':'حذف',
      'deleteProduct':'حذف المنتج','checkout':'إتمام الطلب','printedSuccessfully':'تمت الطباعة بنجاح',
      'shop':'المتجر','total':'الإجمالي','scanToPay':'امسح للدفع','grandTotal':'الإجمالي الكلي','printReceipt':'طباعة الفاتورة',
      'reviewOrder':'مراجعة الطلب','cameraOff':'الكاميرا متوقفة','turnCamera':'فعّل الكاميرا لبدء مسح الباركود والمنتجات تلقائياً.',
      'turnOnCamera':'تشغيل الكاميرا','scannedItems':'المنتجات الممسوحة','itemsTotal':'{count} منتجات إجمالاً',
      'listEmpty':'القائمة فارغة','scanItemsHint':'ستظهر المنتجات هنا عند مسحها بالكاميرا.',
      'scanBarcode':'مسح الباركود','alignBarcode':'ضع الباركود داخل الإطار','productManagement':'إدارة المنتجات',
      'noProducts':'لا توجد منتجات. أضف بعض المنتجات!','noMatches':'لا توجد منتجات مطابقة للبحث.',
      'confirmDelete':'هل أنت متأكد من حذف {name}؟','shopSaved':'تم حفظ تفاصيل المتجر!',
      'generalInfo':'المعلومات العامة','receiptInfo':'ستظهر هذه المعلومات في الفواتير الرقمية والمطبوعة.',
      'shopName':'اسم المتجر','address1':'العنوان 1','address2':'العنوان 2 (اختياري)','phone':'رقم الهاتف',
      'upi':'معرّف UPI','footer':'نص أسفل الفاتورة','maxChars':'150 حرفاً كحد أقصى',
      'save':'حفظ','currency':'العملة','dzd':'الدينار الجزائري (DZD)',
      'connectHelp':'للاتصال بجهاز جديد، افتح إعدادات Bluetooth من زر الإعدادات وقم بإقرانه، ثم عد واضغط تحديث.',
      'refresh':'تحديث','error':'خطأ','required':'مطلوب','cameraScanner':'ماسح الكاميرا',
    },
  };

  String t(String key, {Map<String, String> args = const {}}) {
    var value = _values[locale.languageCode]?[key] ?? _values['en']![key] ?? key;
    args.forEach((k, v) => value = value.replaceAll('{$k}', v));
    return value;
  }

  TextDirection get textDirection => locale.languageCode == 'ar' ? TextDirection.rtl : TextDirection.ltr;
}

class AppLocalizations {
  static AppLocalization of(BuildContext context) {
    final locale = Localizations.localeOf(context);
    return AppLocalization(locale);
  }
}

class AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalization> {
  const AppLocalizationsDelegate();
  @override bool isSupported(Locale locale) => ['en','fr','ar'].contains(locale.languageCode);
  @override Future<AppLocalization> load(Locale locale) async => AppLocalization(locale);
  @override bool shouldReload(covariant AppLocalizationsDelegate old) => false;
}

extension LocalizationX on BuildContext {
  String tr(String key, {Map<String, String> args = const {}}) => AppLocalizations.of(this).t(key, args: args);
}
