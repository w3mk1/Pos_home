
import 'package:intl/intl.dart';

class CurrencyFormatter {
  static String format(double amount) {
    return '${NumberFormat('#,##0.00', 'fr_FR').format(amount)} DZD';
  }
}
