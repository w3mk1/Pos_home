
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:app_settings/app_settings.dart' as device_settings;

import '../../../../core/theme/app_theme.dart';
import '../../../../core/localization/app_settings.dart';
import '../../../../core/localization/app_localization.dart';
import '../../../shop/presentation/bloc/shop_bloc.dart';
import '../bloc/printer_bloc.dart';
import '../bloc/printer_event.dart';
import '../bloc/printer_state.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  void initState() {
    super.initState();
    context.read<PrinterBloc>().add(InitPrinterEvent());
  }

  @override
  Widget build(BuildContext context) {
    final t = context.tr;
    return Scaffold(
      appBar: AppBar(
        title: Text(t('settings'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        leading: IconButton(
          icon: Icon(Icons.chevron_left, size: 28, color: Theme.of(context).primaryColor),
          onPressed: () => context.pop(),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          _buildProfile(context),
          const SizedBox(height: 24),
          _buildSectionHeader(t('appearance')),
          _buildListGroup([
            _buildListItem(
              context, Icons.dark_mode, t('darkMode'),
              subtitle: _themeLabel(context),
              trailing: Switch(
                value: AppSettings.themeMode.value == ThemeMode.dark,
                onChanged: (v) => AppSettings.setThemeMode(v ? ThemeMode.dark : ThemeMode.light),
              ),
            ),
            _buildDivider(),
            _buildListItem(
              context, Icons.language, t('language'),
              subtitle: _languageLabel(context),
              trailing: PopupMenuButton<String>(
                icon: const Icon(Icons.arrow_drop_down),
                onSelected: AppSettings.setLanguage,
                itemBuilder: (_) => [
                  PopupMenuItem(value: 'ar', child: Text(t('arabic'))),
                  PopupMenuItem(value: 'fr', child: Text(t('french'))),
                  PopupMenuItem(value: 'en', child: Text(t('english'))),
                ],
              ),
            ),
            _buildDivider(),
            _buildListItem(
              context, Icons.payments_outlined, t('currency'),
              subtitle: t('dzd'),
              trailing: const Icon(Icons.check_circle, color: AppTheme.primaryColor),
            ),
          ]),
          const SizedBox(height: 24),
          _buildSectionHeader(t('management')),
          _buildListGroup([
            _buildListItem(context, Icons.qr_code_scanner, t('products'),
              subtitle: t('manageProducts'), onTap: () => context.push('/products')),
            _buildDivider(),
            _buildListItem(context, Icons.storefront, t('shopDetails'),
              subtitle: t('editBusiness'), onTap: () => context.push('/shop')),
          ]),
          const SizedBox(height: 24),
          _buildSectionHeader(t('hardware')),
          BlocConsumer<PrinterBloc, PrinterState>(
            listener: (context, state) {
              if (state.errorMessage != null) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(state.errorMessage!), backgroundColor: Colors.red));
              } else if (state.status == PrinterStatus.connected) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t('connectedToPrinter')), backgroundColor: Colors.green));
              }
            },
            builder: (context, state) => _buildListGroup([
              _buildListItem(
                context, Icons.print, t('printDevice'),
                subtitleWidget: Row(children: [
                  Text(state.connectedMac != null ? (state.connectedName ?? t('printerConnected')) : t('noPrinter'),
                    style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
                  if (state.connectedMac != null) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: Colors.teal.withValues(alpha: .15), borderRadius: BorderRadius.circular(10)),
                      child: Text(t('connected'), style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.teal)),
                    )
                  ],
                ]),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  if (state.status == PrinterStatus.scanning || state.status == PrinterStatus.connecting)
                    const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
                  else
                    IconButton(icon: const Icon(Icons.refresh), onPressed: () => context.read<PrinterBloc>().add(RefreshPrinterEvent()), color: AppTheme.primaryColor),
                  IconButton(icon: const Icon(Icons.settings), onPressed: () => AppSettingsPlugin.openBluetooth(), color: Theme.of(context).hintColor),
                ]),
              ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Text(t('connectHelp'), style: TextStyle(fontSize: 11, fontStyle: FontStyle.italic, color: Theme.of(context).hintColor)),
          ),
          const SizedBox(height: 48),
        ]),
      ),
    );
  }

  Widget _buildProfile(BuildContext context) => Container(
    width: double.infinity,
    color: Theme.of(context).colorScheme.surface,
    padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
    child: BlocBuilder<ShopBloc, ShopState>(builder: (context, state) {
      var shopName = 'Elite Groceries';
      var initials = 'EG';
      if (state is ShopLoaded && state.shop.name.isNotEmpty) {
        shopName = state.shop.name;
        initials = shopName.split(' ').take(2).map((p) => p.isNotEmpty ? p[0].toUpperCase() : '').join();
        if (initials.isEmpty) initials = 'S';
      }
      return Column(children: [
        Container(width: 96, height: 96, decoration: BoxDecoration(color: AppTheme.primaryColor, shape: BoxShape.circle),
          alignment: Alignment.center, child: Text(initials, style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold))),
        const SizedBox(height: 16),
        Text(shopName.toUpperCase(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ]);
    }),
  );

  String _themeLabel(BuildContext context) {
    switch (AppSettings.themeMode.value) {
      case ThemeMode.dark: return context.tr('darkMode');
      case ThemeMode.system: return context.tr('systemMode');
      case ThemeMode.light: return context.tr('lightMode');
    }
  }

  String _languageLabel(BuildContext context) {
    switch (AppSettings.locale.value.languageCode) {
      case 'ar': return context.tr('arabic');
      case 'fr': return context.tr('french');
      default: return context.tr('english');
    }
  }

  Widget _buildSectionHeader(String title) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
    child: Align(alignment: AlignmentDirectional.centerStart, child: Text(title.toUpperCase(),
      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey, letterSpacing: 1.2))),
  );

  Widget _buildListGroup(List<Widget> children) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 16),
    decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(12)),
    child: Column(children: children),
  );

  Widget _buildDivider() => Divider(height: 1, indent: 64, color: Theme.of(context).dividerColor);

  Widget _buildListItem(BuildContext context, IconData icon, String title, {
    String? subtitle, Widget? subtitleWidget, Widget? trailing, VoidCallback? onTap,
  }) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(12),
    child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
      Container(width: 40, height: 40, decoration: BoxDecoration(color: AppTheme.primaryColor.withValues(alpha: .1), borderRadius: BorderRadius.circular(8)),
        child: Icon(icon, color: AppTheme.primaryColor, size: 20)),
      const SizedBox(width: 16),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        if (subtitle != null) ...[const SizedBox(height: 2), Text(subtitle, style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor))],
        if (subtitleWidget != null) ...[const SizedBox(height: 4), subtitleWidget],
      ])),
      if (trailing != null) trailing else Icon(Icons.chevron_right, color: Theme.of(context).disabledColor),
    ])),
  );
}

class AppSettingsPlugin {
  static Future<void> openBluetooth() => device_settings.AppSettings.openAppSettings(type: device_settings.AppSettingsType.bluetooth);
}
